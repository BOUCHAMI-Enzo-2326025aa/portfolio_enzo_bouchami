
  # Portfolio d'Enzo Bouchami

  This is a code bundle for Portfolio d'Enzo Bouchami. The original project is available at https://www.figma.com/design/vL9aUB5bt11qnGv5OuqPtb/Portfolio-d-Enzo-Bouchami.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  